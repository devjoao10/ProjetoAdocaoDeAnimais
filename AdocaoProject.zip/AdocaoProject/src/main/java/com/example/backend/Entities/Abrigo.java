/*
package com.example.backend;

import java.util.ArrayList;
import java.util.List;

public class Abrigo {

    private Integer id;
    private String nome;
    private String endereco;
    private AnimalList animais;

    public Abrigo(Integer id, String nome, String endereco, AnimalList animais) {
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
        this.animais = animais;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public List<Animal> getAnimais() {
        return animais;
    }

    public void addAnimal(AnimalList animal) {
        animal.getAnimais();
    }

    public void removeAnimal(AnimalList animal) {
        animal.getAnimais();
    }
}
*/