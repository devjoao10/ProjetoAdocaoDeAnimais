package com.example.backend;

import com.example.backend.Consulta.ConsultaAnimal;
import com.example.backend.DAO.AnimalDAO;
import com.example.backend.Entities.Animal;

import java.util.Scanner;

public class MainDoacao{
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        AnimalDAO animalDAO = new AnimalDAO();
        String tipo;
        int escolha;

        System.out.println("Seja bem vindo ao sistema de cadastro de animais doados:");

        do {
            System.out.print("Nome do animal: ");
            String nome = scan.nextLine();
            System.out.print("Raça: ");
            String raca = scan.nextLine();
            do {
                System.out.print("Tipo (c para cachorro, g para gato): ");
                tipo = scan.nextLine().toLowerCase();
                if (!tipo.equals("c") && !tipo.equals("g")) {
                    System.out.println("Tipo invalido, tente novamente!");
                }
            } while (!tipo.equals("c") && !tipo.equals("g"));

            System.out.print("Idade: ");
            int idade = scan.nextInt();
            scan.nextLine();

            Animal animal = new Animal(tipo, null, raca, idade, nome);
            animalDAO.addAnimal(animal);
            ConsultaAnimal consultaAnimal = new ConsultaAnimal();
            consultaAnimal.obterAnimais();
            System.out.println("Animal cadastrado com sucesso!");

            System.out.print("Deseja cadastrar outro animal? (1 para sim, 2 para não): ");
            escolha = scan.nextInt();
            scan.nextLine();
        } while (escolha == 1);
    }
}
