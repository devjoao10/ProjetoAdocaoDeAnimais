package com.example.backend.Entities;

public class Doacao implements Evento {
    private int id;
    private Animal animal;

    public Doacao (Animal animal){
        this.animal = animal;
    }

    public Animal getAnimal() {
        return animal;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    @Override
    public void realizarEvento(){
        System.out.println("Doação do " + animal.getNome() + " realizada com sucesso!");
    }
}
