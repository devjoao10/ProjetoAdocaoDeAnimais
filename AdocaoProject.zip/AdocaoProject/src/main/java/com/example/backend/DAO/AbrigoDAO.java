/*package com.example.backend.DAO;

import com.example.backend.Abrigo;
import com.example.backend.Conexao.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AbrigoDAO {
    public void addAbrigo(Abrigo abrigo) {
        String sql = "INSERT INTO abrigo (nome, endereco) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, abrigo.getNome());
            stmt.setString(2, abrigo.getEndereco());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
*/