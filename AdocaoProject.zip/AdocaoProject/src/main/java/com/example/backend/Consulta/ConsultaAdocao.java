package com.example.backend.Consulta;


import com.example.backend.Entities.Adocao;
import com.example.backend.Listas.AdocaoList;
import com.example.backend.Conexao.DatabaseConnection;

import java.sql.*;

public class ConsultaAdocao {

    public AdocaoList obterAdotantes() {
        AdocaoList  adocaoList = new AdocaoList ();
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseConnection.getConnection();
            statement = connection.createStatement();
            String sql = "SELECT * FROM adocao";
            resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                int adocao_id = resultSet.getInt("adocao_id");
                int animal_id = resultSet.getInt("animal_id");
                int adotante_id = resultSet.getInt("adotante_id");
                Date data = resultSet.getDate("data_adocao");
                Adocao adocao = new Adocao(adocao_id, animal_id, adotante_id, data);
                adocaoList.addAdocao(adocao);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return adocaoList;
    }
}
