package com.example.backend.DAO;

import com.example.backend.Entities.Adotante;
import com.example.backend.Conexao.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdotanteDAO {
    public void addAdotante(Adotante adotante) {
        String sql = "INSERT INTO adotantes (nome, cpf, endereco, email, telefone) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, adotante.getNome());
            stmt.setString(2, adotante.getCpf());
            stmt.setString(3, adotante.getEndereco());
            stmt.setString(4, adotante.getEmail());
            stmt.setString(5, adotante.getTelefone());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int getUltimoAdotanteId() {
        String sql = "SELECT MAX(adotante_id) AS max_id FROM adotantes";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt("max_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;  // Retorna -1 se não encontrar um ID válido
    }
}
