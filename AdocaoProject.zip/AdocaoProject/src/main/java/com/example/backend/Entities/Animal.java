package com.example.backend.Entities;


public class Animal {
    private Integer id;
    private String tipo;
    private String raca;
    private Integer idade;
    private String nome;


    public Animal(String tipo, Integer id, String raca, Integer idade, String nome) {
        this.tipo = tipo;
        this.id = id;
        this.raca = raca;
        this.idade = idade;
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String especie) {
        this.raca = especie;
    }

    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        this.idade = idade;
    }
}
