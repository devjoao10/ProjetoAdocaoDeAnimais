package com.example.backend;

import com.example.backend.DAO.AdocaoDAO;
import com.example.backend.DAO.AdotanteDAO;
import com.example.backend.DAO.AnimalDAO;
import com.example.backend.Entities.Adocao;
import com.example.backend.Entities.Adotante;
import com.example.backend.Entities.Animal;
import com.example.backend.Listas.AnimalList;


import java.util.Scanner;
import java.util.Date;

public class MainAdocao {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        AdotanteDAO adotanteDAO = new AdotanteDAO();
        AnimalDAO animalDAO = new AnimalDAO();
        AdocaoDAO adocaoDAO = new AdocaoDAO();
        AnimalList animalList = new AnimalList();
        String tipo;

        System.out.println("Seja bem vindo ao sistema de adocao: ");
        System.out.println("Vamos começar com seu cadastro de adotante:");

        System.out.print("Nome: ");
        String nome = scan.nextLine();
        System.out.print("CPF: ");
        String cpf = scan.nextLine();
        System.out.print("Email: ");
        String email = scan.nextLine();
        System.out.print("Telefone: ");
        String telefone = scan.nextLine();
        System.out.print("Endereco: ");
        String endereco = scan.nextLine();

        Adotante adotante = new Adotante(nome, null, cpf, endereco, email, telefone);
        adotanteDAO.addAdotante(adotante);

        // Perguntar qual tipo de animal deseja adotar
        do {
            System.out.print("Tipo de animal que deseja adotar (c para cachorro, g para gato): ");
            tipo = scan.nextLine().toLowerCase();
            if (!tipo.equals("c") && !tipo.equals("g")) {
                System.out.println("Tipo invalido, tente novamente!");
            }
        } while (!tipo.equals("c") && !tipo.equals("g"));


        if (animalList.getAnimais().isEmpty()) {
            System.out.println("Nenhum animal disponível para adoção desse tipo.");
            return;
        }

        System.out.println("Animais disponíveis para adoção:");
        animalList.exibirAnimaisPorTipo(tipo);


        System.out.print("Digite o ID do animal que deseja adotar: ");
        int animalId = scan.nextInt();
        scan.nextLine();

        Animal animalEscolhido = null;
        for (Animal animal : animalList.getAnimais()) {
            if (animal.getId() == animalId) {
                animalEscolhido = animal;
                break;
            }
        }

        if (animalEscolhido == null) {
            System.out.println("Animal não encontrado.");
            return;
        }

        // Confirmar adoção
        System.out.print("Confirmar adoção? (s para sim, n para não): ");
        String confirmacao = scan.nextLine().toLowerCase();
        if (confirmacao.equals("s")) {
            Adocao adocao = new Adocao(adotante.getId(), animalEscolhido.getId());
            adocaoDAO.addAdocao(adocao);
            System.out.println("Adoção realizada com sucesso!");
        } else {
            System.out.println("Adoção cancelada.");
        }
    }
}