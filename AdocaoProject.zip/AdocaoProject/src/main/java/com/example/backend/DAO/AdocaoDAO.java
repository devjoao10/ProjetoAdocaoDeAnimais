package com.example.backend.DAO;

import com.example.backend.Entities.Adocao;
import com.example.backend.Conexao.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AdocaoDAO {
    public void addAdocao(Adocao adocao) {
        String sql = "INSERT INTO adocao (adotante_id, animal_id, data_adocao) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, adocao.getAdotanteId());
            stmt.setInt(2, adocao.getAnimalId());
            stmt.setTimestamp(3, new java.sql.Timestamp(adocao.getDataAdocao().getTime()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void removeAdocao(int adocaoId) {
        String sql = "DELETE FROM adocao WHERE adocao_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, adocaoId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
