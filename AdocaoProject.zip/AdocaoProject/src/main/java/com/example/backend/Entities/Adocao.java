package com.example.backend.Entities;

import java.util.Date;

public class Adocao implements Evento {
    private int id;
    private int animal_id;
    private int adotante_id;
    private Adotante adotante;
    private Animal animal;
    private Date dataAdocao;

    public Adocao(Adotante adotante, Animal animal){
        this.adotante = adotante;
        this.animal = animal;
        this.animal_id = animal.getId();
        this.adotante_id = adotante.getId();
        this.dataAdocao = new Date();
    }

    public Adocao(int id, int animal_id, int adotante_id, Date dataAdocao){
        this.id = id;
        this.animal_id = animal_id;
        this.adotante_id = adotante_id;
        this.dataAdocao = dataAdocao;
    }








    public Adocao(int adotante_id, int animal_id) {
        this.id = id;
        this.adotante_id = adotante_id;
        this.animal_id = animal_id;
        this.dataAdocao = dataAdocao;
    }
    public int getId() {
        return id;
    }

    public int getAdotanteId() {
        return adotante_id;
    }

    public int getAnimalId() {
        return animal_id;
    }

    public Adotante getAdotante() {
        return adotante;
    }

    public void setAdotante(Adotante adotante) {
        this.adotante = adotante;
    }

    public Animal getAnimal() {
        return animal;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    public Date getDataAdocao() {
        return dataAdocao;
    }

    public void setDataAdocao(Date dataAdocao) {
        this.dataAdocao = dataAdocao;
    }

    @Override
    public void realizarEvento() {
        System.out.println("Adoção realizada por " + adotante.getNome() + " para o animal " + animal.getNome());
    }
}
