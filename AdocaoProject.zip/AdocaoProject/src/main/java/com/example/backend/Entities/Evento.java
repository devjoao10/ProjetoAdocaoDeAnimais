package com.example.backend.Entities;

public interface Evento {

    void realizarEvento();

}
