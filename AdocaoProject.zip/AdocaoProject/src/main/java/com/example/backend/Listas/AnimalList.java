package com.example.backend.Listas;

import com.example.backend.Entities.Animal;

import java.util.ArrayList;
import java.util.List;

public class AnimalList {
    private List<Animal> animais;

    public AnimalList() {
        animais = new ArrayList<>();
    }

    public void addAnimal(Animal animal) {
        animais.add(animal);
    }

    public List<Animal> getAnimais() {
        return animais;
    }

    public void exibirAnimaisPorTipo(String tipo) {
        tipo = tipo.toLowerCase();
        for (Animal animal : animais) {
            if (String.valueOf(animal.getTipo()).equalsIgnoreCase(tipo)) {
                System.out.println("ID: " + animal.getId());
                System.out.println("Nome: " + animal.getNome());
                System.out.println("Raça: " + animal.getRaca());
                System.out.println("Idade: " + animal.getIdade());
                System.out.println("Tipo: " + (tipo.equals("c") ? "Cachorro" : "Gato"));
                System.out.println("-----------------------");
            }
        }
    }
}




