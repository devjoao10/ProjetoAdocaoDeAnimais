package com.example.backend.Consulta;


import com.example.backend.Entities.Adotante;
import com.example.backend.Listas.AdotanteList;
import com.example.backend.Conexao.DatabaseConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConsultaAdotante {

    public AdotanteList obterAdotantes() {
        AdotanteList adotanteList = new AdotanteList();
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseConnection.getConnection();
            statement = connection.createStatement();
            String sql = "SELECT * FROM adotantes";
            resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                int id = resultSet.getInt("adotante_id");
                String nome = resultSet.getString("nome");
                String cpf = resultSet.getString("cpf");
                String endereco = resultSet.getString("endereco");
                String email = resultSet.getString("email");
                String telefone = resultSet.getString("telefone");

                Adotante adotante = new Adotante(nome, id, cpf, endereco, email ,telefone);
                adotanteList.addAdotante(adotante);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return adotanteList;
    }
}
