package com.example.backend.Listas;

import com.example.backend.Entities.Adotante;

import java.util.ArrayList;
import java.util.List;

public class AdotanteList {
    private List<Adotante> adotantes;

    public AdotanteList(){
        adotantes = new ArrayList<>();
    }

    public void addAdotante(Adotante adotante){
        adotantes.add(adotante);
    }

    public List<Adotante> getAdotantes() {
        return adotantes;
    }

    public void exibirAdotantes() {
        for (Adotante adotante : adotantes) {
            System.out.println("ID: " + adotante.getId());
            System.out.println("Nome: " + adotante.getNome());
            System.out.println("CPF: " + adotante.getCpf());
            System.out.println("Endereço: " + adotante.getEndereco());
            System.out.println("Email: " + adotante.getEmail());
            System.out.println("Telefone: " + adotante.getTelefone());
            System.out.println("-----------------------");
        }
    }
}

