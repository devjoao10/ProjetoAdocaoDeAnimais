package com.example.backend.Listas;

import com.example.backend.Entities.Adocao;

import java.util.ArrayList;
import java.util.List;

public class AdocaoList {
    private List<Adocao> adocoes;

    public AdocaoList() {
        adocoes = new ArrayList<>();
    }

    public void addAdocao(Adocao adocao) {
        adocoes.add(adocao);
    }

    public List<Adocao> getAdocoes() {
        return adocoes;
    }

    public void exibirAdocoes() {
        for (Adocao adocao : adocoes) {
            System.out.println("ID: " + adocao.getId());
            System.out.println("Adotante: " + adocao.getAdotante().getNome());
            System.out.println("Animal: " + adocao.getAnimal().getNome());
            System.out.println("Data de Adocao: " + adocao.getDataAdocao());
            System.out.println("-----------------------");
        }
    }
}
