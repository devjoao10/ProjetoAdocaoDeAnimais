import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AbrigoDAO {
    public void addAbrigo(String nome, String endereco, String telefone) {
        String sql = "INSERT INTO abrigo (nome, endereco, telefone) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setString(2, endereco);
            stmt.setString(3, telefone);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
