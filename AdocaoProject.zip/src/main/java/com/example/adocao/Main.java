public class Main {
    public static void main(String[] args) {
        AbrigoDAO abrigoDAO = new AbrigoDAO();
        abrigoDAO.addAbrigo("Abrigo do Bem", "Rua Exemplo, 123", "123456789");
        System.out.println("Abrigo adicionado com sucesso!");
    }
}
